﻿using System;
using System.Text;
namespace SAES_GCM_CCM
{

    class Run
    {
        public static void Main(string[] args)
        {
            // GCM gcm = new GCM();
            CCM ccm = new CCM();
        }
    }
}