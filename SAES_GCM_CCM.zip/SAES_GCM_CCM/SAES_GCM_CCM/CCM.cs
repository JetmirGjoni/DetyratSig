﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAES_GCM_CCM
{
    internal class CCM
    {
        private static int[][] P = new int[][] { new int[] { 1, 1 }, new int[] { 1, 1 } };
        private static int[][] K = new int[][] { new int[] { 10, 5 }, new int[] { 3, 12 } };
        private static int[][] nonce = new int[][] { new int[] { 1, 1 }, new int[] { 1, 1 } }; 

        
        private static int[][] MAC = new int[][]
        {
        new int[] { 0, 1 }, 
        new int[] { 1, 0 }
        };

        
        public static void CCMFileEncrypt(string inputFilePath, string encryptedFilePath, string macFilePath)
        {
            StringBuilder cipherText = new StringBuilder();
            StringBuilder macText = new StringBuilder();

           
            string fileContent = File.ReadAllText(inputFilePath);

            
            if (fileContent.Length % 2 != 0)
            {
                fileContent += " ";
            }

           
            for (int i = 0; i < fileContent.Length; i += 2)
            {
               
                int[][] cipherBlock = ProcessFilePairEncrypt(fileContent[i], fileContent[i + 1]);

                
                AppendEncryptedText(cipherBlock, cipherText);
            }

           
            File.WriteAllText(encryptedFilePath, cipherText.ToString());
            AppendMACText(MAC, macText);
            File.WriteAllText(macFilePath, macText.ToString());

            Console.WriteLine("Encryption complete.");
        }

       
        public static void CCMFileDecrypt(string encryptedFilePath, string macFilePath, string decryptedFilePath)
        {
            StringBuilder decryptedText = new StringBuilder();

           
            string encryptedContent = File.ReadAllText(encryptedFilePath);
            string macContent = File.ReadAllText(macFilePath);

           
            if (encryptedContent.Length % 2 != 0 || macContent.Length % 2 != 0)
            {
                throw new InvalidOperationException("error.");
            }

           
            for (int i = 0; i < encryptedContent.Length; i += 2)
            {
              
                ProcessFilePairDecrypt(encryptedContent[i], encryptedContent[i + 1], decryptedText);
            }

           
            bool macValid = VerifyMAC(macContent);
            if (!macValid)
            {
                throw new InvalidOperationException("verification failed.");
            }

           
            File.WriteAllText(decryptedFilePath, decryptedText.ToString());

            Console.WriteLine("Decryption complete.");
        }


        private static int[][] ProcessFilePairEncrypt(char ch1, char ch2)
        {
   
            string asciiS1 = Convert.ToString((int)ch1, 2).PadLeft(8, '0');
            int p1 = Convert.ToInt32(asciiS1.Substring(0, 4), 2);
            int p2 = Convert.ToInt32(asciiS1.Substring(4, 4), 2);

     
            string asciiS2 = Convert.ToString((int)ch2, 2).PadLeft(8, '0');
            int p3 = Convert.ToInt32(asciiS2.Substring(0, 4), 2);
            int p4 = Convert.ToInt32(asciiS2.Substring(4, 4), 2);

      
            int[][] P = new int[2][] { new int[] { p1, p3 }, new int[] { p2, p4 } };

   
            return CTR(P, K, nonce, 0);
        }

       
        private static void ProcessFilePairDecrypt(char ch1, char ch2, StringBuilder decryptedText)
        {
      
            string encryptedS1 = Convert.ToString((int)ch1, 2).PadLeft(8, '0');
            int c1 = Convert.ToInt32(encryptedS1.Substring(0, 4), 2);
            int c2 = Convert.ToInt32(encryptedS1.Substring(4, 4), 2);

            string encryptedS2 = Convert.ToString((int)ch2, 2).PadLeft(8, '0');
            int c3 = Convert.ToInt32(encryptedS2.Substring(0, 4), 2);
            int c4 = Convert.ToInt32(encryptedS2.Substring(4, 4), 2);


            int[][] cipherText = new int[2][] { new int[] { c1, c3 }, new int[] { c2, c4 } };

          
            int[][] decryptedBlock = CTR(cipherText, K, nonce, 0);

           
            string d1d2S = Convert.ToString(decryptedBlock[0][0], 2).PadLeft(4, '0') + Convert.ToString(decryptedBlock[1][0], 2).PadLeft(4, '0');
            string d1d2 = ConvertToChar(d1d2S);

            string d3d4S = Convert.ToString(decryptedBlock[0][1], 2).PadLeft(4, '0') + Convert.ToString(decryptedBlock[1][1], 2).PadLeft(4, '0');
            string d3d4 = ConvertToChar(d3d4S);

            decryptedText.Append(d1d2).Append(d3d4);
        }


        private static void AppendEncryptedText(int[][] cipherT, StringBuilder cipherText)
        {
            string c1c2S = Convert.ToString(cipherT[0][0], 2) + Convert.ToString(cipherT[1][0], 2);
            string c1c2 = ConvertToChar(c1c2S);

            string c3c4S = Convert.ToString(cipherT[0][1], 2) + Convert.ToString(cipherT[1][1], 2);
            string c3c4 = ConvertToChar(c3c4S);

            cipherText.Append(c1c2).Append(c3c4);
        }


        private static void AppendMACText(int[][] macT, StringBuilder macText)
        {
            string m1m2S = Convert.ToString(macT[0][0], 2) + Convert.ToString(macT[1][0], 2);
            string m1m2 = ConvertToChar(m1m2S);

            string m3m4S = Convert.ToString(macT[0][1], 2) + Convert.ToString(macT[1][1], 2);
            string m3m4 = ConvertToChar(m3m4S);

            macText.Append(m1m2).Append(m3m4);
        }

        
        private static bool VerifyMAC(string macContent)
        {
        
            StringBuilder macText = new StringBuilder();
            AppendMACText(MAC, macText);

            
            return macContent == macText.ToString();
        }

 
        private static string ConvertToChar(string binaryString)
        {
            int charCode = Convert.ToInt32(binaryString, 2);
            return char.ConvertFromUtf32(charCode);
        }


        private static int[][] CTR(int[][] plaintext, int[][] key, int[][] nonce, int counter)
        {
            int[][] counterBlock = new int[][] { new int[] { counter, 0 }, new int[] { 0, 0 } };
            int[][] encryptedCounter = Encrypt(GCMXOR(counterBlock, nonce), key);
            return GCMXOR(plaintext, encryptedCounter); 
        }


        private static int[][] GCMXOR(int[][] a, int[][] b)
        {
            return new int[][]
            {
            new int[] { a[0][0] ^ b[0][0], a[0][1] ^ b[0][1] },
            new int[] { a[1][0] ^ b[1][0], a[1][1] ^ b[1][1] }
            };
        }

        
        private static int[][] Encrypt(int[][] plaintext, int[][] key)
        {
            
            return plaintext; 
        }

     
        public CCM()
        {
            string inputFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\plaintext.txt";
            string encryptedFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\encrypted.txt";
            string macFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\mac.txt";
            string decryptedFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\decrypted.txt";

        
            CCMFileEncrypt(inputFilePath, encryptedFilePath, macFilePath);

          
            CCMFileDecrypt(encryptedFilePath, macFilePath, decryptedFilePath);
        }


    }
}
