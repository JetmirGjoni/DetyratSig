﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAES_GCM_CCM
{
    public class GCM
    {

       
            private static int[][] P = new int[][] { new int[] { 1, 1 }, new int[] { 1, 1 } };
            private static int[][] K = new int[][] { new int[] { 10, 5 }, new int[] { 3, 12 } };
            static Helper helper = new Helper();
            static Encryption encryption = new Encryption();
            static Decryption decryption = new Decryption();
            static int[][] celsi1 = helper.KeyGenerator(K, 1, helper.SBOX);
            static int[][] celsi2 = helper.KeyGenerator(celsi1, 2, helper.SBOX);
            static int[][] celsi3 = helper.KeyGenerator(celsi2, 3, helper.SBOX);

            
            private static readonly int irreduciblePolynomial = Convert.ToInt32("210013", 8);

  
            public static int GaloisFieldMultiply(int x, int y)
            {
                int result = 0;
                for (int i = 0; i < 16; i++)
                {
                    if ((y & 1) == 1)
                        result ^= x;

                    bool carry = (x & 0x8000) != 0;
                    x <<= 1;
                    if (carry)
                        x ^= irreduciblePolynomial;
                    y >>= 1;
                }
                return result & 0xFFFF; 
            }

            
            public static int[][] EncryptCTR(int[][] plaintext, int[][] key, int[][] counter)
            {
                int[][] ciphertext = new int[plaintext.Length][];
                for (int i = 0; i < plaintext.Length; i++)
                {
                    int[][] encryptedCounter = encryption.PaK(counter, key);
                    ciphertext[i] = new int[plaintext[i].Length];
                    for (int j = 0; j < plaintext[i].Length; j++)
                    {
                        ciphertext[i][j] = plaintext[i][j] ^ encryptedCounter[i][j];
                    }
                    IncrementCounter(counter);
                }
                return ciphertext;
            }

            private static void IncrementCounter(int[][] counter)
            {
                counter[1][1]++;
                if (counter[1][1] == 0)
                {
                    counter[1][0]++;
                    if (counter[1][0] == 0)
                    {
                        counter[0][1]++;
                        if (counter[0][1] == 0)
                        {
                            counter[0][0]++;
                        }
                    }
                }
            }

          
            public static int[][] AuthenticateGCM(int[][] data, int[][] additionalData)
            {
                int[][] tag = new int[2][] { new int[2], new int[2] };
                for (int i = 0; i < additionalData.Length; i++)
                {
                    for (int j = 0; j < additionalData[i].Length; j++)
                    {
                        tag[0][0] ^= additionalData[i][j];
                        tag[1][0] ^= additionalData[i][j];
                        tag[0][1] ^= additionalData[i][j];
                        tag[1][1] ^= additionalData[i][j];
                    }
                    tag[0][0] = GaloisFieldMultiply(tag[0][0], additionalData[i][0]);
                    tag[1][0] = GaloisFieldMultiply(tag[1][0], additionalData[i][1]);
                }

                for (int i = 0; i < data.Length; i++)
                {
                    for (int j = 0; j < data[i].Length; j++)
                    {
                        tag[0][0] ^= data[i][j];
                        tag[1][0] ^= data[i][j];
                        tag[0][1] ^= data[i][j];
                        tag[1][1] ^= data[i][j];
                    }
                    tag[0][0] = GaloisFieldMultiply(tag[0][0], data[i][0]);
                    tag[1][0] = GaloisFieldMultiply(tag[1][0], data[i][1]);
                }

                return tag;
            }

           
            public static void GCMSAES()
            {
               
                string plaintextFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\plaintext.txt";
                string encryptedFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\encrypted.txt";
                string tagFilePath = "C:\\Program Files\\ProgramRepos\\SAES_GCM_CCM\\SAES_GCM_CCM\\tag.txt";

                
                string plaintextText = File.ReadAllText(plaintextFilePath);

                
                int[][] plaintext = StringToMatrix(plaintextText);

               
                int[][] additionalData = new int[][]
                {
                new int[] { 0x1111, 0x2222 },
                new int[] { 0x3333, 0x4444 }
                };

               
                int[][] counter = new int[][] { new int[] { 0x0000, 0x0000 }, new int[] { 0x0000, 0x0001 } };

               
                int[][] ciphertext = EncryptCTR(plaintext, K, counter);

               
                int[][] tag = AuthenticateGCM(ciphertext, additionalData);

                
                File.WriteAllText(encryptedFilePath, MatrixToString(ciphertext));
                File.WriteAllText(tagFilePath, MatrixToString(tag));

                Console.WriteLine("Authentication completed.");
            }

            
            private static int[][] StringToMatrix(string text)
            {
                int[][] matrix = new int[2][];
                matrix[0] = new int[] { text[0], text[1] };
                matrix[1] = new int[] { text[2], text[3] };
                return matrix;
            }

           
            private static string MatrixToString(int[][] matrix)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < matrix.Length; i++)
                {
                    for (int j = 0; j < matrix[i].Length; j++)
                    {
                        sb.Append(Convert.ToString(matrix[i][j], 16).PadLeft(4, '0'));
                    }
                }
                return sb.ToString();
            }



        }
}
