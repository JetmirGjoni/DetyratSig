﻿namespace DetyraSiguriSAES
{
    internal class Helper
    {
        public int[][] SBOX = new int[][]
{    new int[] { 6, 11, 0, 4 },    new int[] { 7, 14, 2, 15 },    new int[] { 9, 8, 10, 12 },    new int[] { 3, 1, 5, 13 }        };


        public int[][] tabelaShumzimit = new int[][]
{
    new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 },
    new int[] { 0, 2, 4, 6, 8, 10, 12, 14, 3, 1, 7, 5, 11, 9, 15, 13 },
    new int[] { 0, 3, 6, 5, 12, 15, 10, 9, 11, 8, 13, 14, 7, 4, 1, 2 },
    new int[] { 0, 4, 8, 12, 3, 7, 11, 15, 6, 2, 14, 10, 5, 1, 13, 9 },
    new int[] { 0, 5, 10, 15, 7, 2, 13, 8, 14, 11, 4, 1, 9, 12, 3, 6 },
    new int[] { 0, 6, 12, 10, 11, 13, 7, 1, 5, 3, 9, 15, 14, 8, 2, 4 },
    new int[] { 0, 7, 14, 9, 15, 8, 1, 6, 13, 10, 3, 4, 2, 5, 12, 11 },
    new int[] { 0, 8, 3, 11, 6, 14, 5, 13, 12, 4, 15, 7, 10, 2, 9, 1 },
    new int[] { 0, 9, 1, 8, 2, 11, 3, 10, 4, 13, 5, 12, 6, 15, 7, 14 },
    new int[] { 0, 10, 7, 13, 14, 4, 9, 3, 15, 5, 8, 2, 1, 11, 6, 12 },
    new int[] { 0, 11, 5, 14, 10, 1, 15, 4, 7, 12, 2, 9, 13, 6, 8, 3 },
    new int[] { 0, 12, 11, 7, 5, 9, 14, 2, 10, 6, 1, 13, 15, 3, 4, 8 },
    new int[] { 0, 13, 9, 4, 1, 12, 8, 5, 2, 15, 11, 6, 3, 14, 10, 7 },
    new int[] { 0, 14, 15, 1, 13, 3, 2, 12, 9, 7, 6, 8, 4, 10, 11, 5 },
    new int[] { 0, 15, 13, 2, 9, 6, 4, 11, 1, 14, 12, 3, 8, 7, 5, 10 }
};
        public int[][] InvSBOX = new int[][]
{
    new int[] { 2, 13, 6, 12 },
    new int[] { 3, 14, 0, 4 },
    new int[] { 9, 8, 10, 1 },
    new int[] { 11, 15, 5, 7 }
};
        public int G(int a, int rundi, int[][] SB)
        {
            string ku = Convert.ToString(a, 2);
            string k = ku.PadLeft(4, '0');

            string k0S = k[3].ToString();
            string k1S = k[1].ToString();
            string k2S = k[2].ToString();
            string k3S = k[0].ToString();

            string rreshtiS = k1S + k2S;
            int rreshti = Convert.ToInt32(rreshtiS, 2);

            string kolonaS = k0S + k3S;
            int kolona = Convert.ToInt32(kolonaS, 2);

            int subytes = SB[rreshti][kolona];

            if (rundi == 1)
            {
                return subytes ^ 1;
            }
            else if (rundi == 2)
            {
                return 2 ^ subytes;
            }
            else if (rundi == 3)
            {
                return 4 ^ subytes;
            }

            return -1;
        }


        public int[][] KeyGenerator(int[][] C, int rundi, int[][] SB)
        {


            int k0 = C[0][0];
            int k1 = C[1][0];
            int k2 = C[0][1];
            int k3 = C[1][1];
            int Gk3 = G(k3, rundi, SB);

            int kp0 = k0 ^ Gk3;
            int kp1 = k1 ^ kp0;
            int kp2 = k2 ^ kp1;
            int kp3 = k3 ^ kp2;

            return new int[][]
            {
        new int[] { kp0, kp2 },
        new int[] { kp1, kp3 }
            };
        }
        public int[][] GCMXOR(int[][] a, int[][] b)
        {
            return new int[][]
            {
        new int[] { a[0][0] ^ b[0][0], a[0][1] ^ b[0][1] },
        new int[] { a[1][0] ^ b[1][0], a[1][1] ^ b[1][1] }
            };
        }

    }
}
