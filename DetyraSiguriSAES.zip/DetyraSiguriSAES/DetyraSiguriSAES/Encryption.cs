﻿namespace DetyraSiguriSAES
{
    internal class Encryption
    {

       public  Helper helper = new Helper();

        public Encryption() { }

        public int[][] PaK(int[][] P, int[][] K)
        {
            return new int[][]
            {
        new int[] { P[0][0] ^ K[0][0], P[0][1] ^ K[0][1] },
        new int[] { P[1][0] ^ K[1][0], P[1][1] ^ K[1][1] }
            };
        }

        public int[][] ShiftRows(int[][] a)
        {
            int save1 = a[1][0];
            a[1][0] = a[1][1];
            a[1][1] = save1;

            return a;
        }

        public int[][] Substitution_SBOX(int[][] a, int[][] SB)
        {
            int[][] result = new int[2][];
            for (int i = 0; i < 2; i++)
            {
                result[i] = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    string binary = Convert.ToString(a[i][j], 2).PadLeft(4, '0');
                    int row = Convert.ToInt32(binary.Substring(0, 2), 2);
                    int col = Convert.ToInt32(binary.Substring(2, 2), 2);
                    result[i][j] = SB[row][col];
                }
            }
            return result;
        }

        public int[][] MixColumns(int[][] a)
        {
            int[][] MDS = new int[][] { new int[] { 1, 1 }, new int[] { 1, 2 } };

            int mds0 = MDS[0][0];
            int mds1 = MDS[1][0];
            int mds2 = MDS[0][1];
            int mds3 = MDS[1][1];

            int a0 = a[0][0];
            int a1 = a[1][0];//a1 og
            int a2 = a[0][1];//a2 og
            int a3 = a[1][1];

            int p1 = helper.tabelaShumzimit[mds0][a0] ^ helper.tabelaShumzimit[mds2][a1];
            int p2 = helper.tabelaShumzimit[mds0][a2] ^ helper.tabelaShumzimit[mds2][a3];
            int p3 = helper.tabelaShumzimit[mds1][a0] ^ helper.tabelaShumzimit[mds3][a1];
            int p4 =  helper.tabelaShumzimit[mds1][a2] ^ helper.tabelaShumzimit[mds3][a3];

            return new int[][]
            {
        new int[] { p1, p2 },
        new int[] { p3, p4 }
            };
        }

        public int[][] AddRoundKey(int[][] d, int[][] k)
        {
            return new int[][]
            {
        new int[] { d[0][0] ^ k[0][0], d[0][1] ^ k[0][1] },
        new int[] { d[1][0] ^ k[1][0], d[1][1] ^ k[1][1] }
            };
        }



        public void PrintMatrix(int[][] matrix)
        {
         
            for (int i = 0; i < matrix.Length; i++)  
            {
                for (int j = 0; j < matrix[i].Length; j++) 
                {
                    Console.Write(matrix[i][j] + " ");
                }
                Console.WriteLine();
            }
        }

    }
}
