﻿using DetyraSiguriSAES;
using System;
using System.IO;
using System.Text;

public class AESProcessor
{
    private static int[][] P = new int[][] { new int[] { 1, 1 }, new int[] { 1, 1 } };
    private static int[][] K = new int[][] { new int[] { 10, 5 }, new int[] { 3, 12 } };
    static Helper helper = new Helper();
    static Encryption encryption = new Encryption();
    static Decryption decryption = new Decryption();
    static int[][] celsi1 = helper.KeyGenerator(K, 1, helper.SBOX);
    static int[][] celsi2 = helper.KeyGenerator(celsi1, 2, helper.SBOX);
    static int[][] celsi3 = helper.KeyGenerator(celsi2, 3, helper.SBOX);

    public static void SAES()
    {
        StringBuilder decrypted = new StringBuilder();
        StringBuilder cipherText = new StringBuilder();

       
        string inputFilePath = "C:\\Program Files\\ProgramRepos\\DetyraSiguriSAES\\DetyraSiguriSAES\\plaintext.txt";
        string encryptedFilePath = "C:\\Program Files\\ProgramRepos\\DetyraSiguriSAES\\DetyraSiguriSAES\\encrypted.txt";
        string decryptedFilePath = "C:\\Program Files\\ProgramRepos\\DetyraSiguriSAES\\DetyraSiguriSAES\\decrypted.txt";

   
        string file = File.ReadAllText(inputFilePath);

        
        if (file.Length % 2 != 0)
        {
            file += " ";
        }

       
        for (int i = 0; i < file.Length; i += 2)
        {
            ProcessPair(file[i], file[i + 1], cipherText, decrypted, "saes");
        }

    
        File.WriteAllText(encryptedFilePath, cipherText.ToString());


        File.WriteAllText(decryptedFilePath, decrypted.ToString());

        
        Console.WriteLine("Teksti i enkriptuar: ");
        Console.WriteLine(cipherText.ToString());
        Console.WriteLine("Teksti i dekriptuar: " + decrypted.ToString());
    }


    private static void ProcessPair(char ch1, char ch2, StringBuilder cipherText, StringBuilder decrypted,string mode)
    {


        // shkronja1
        string asciiS1 = Convert.ToString((int)ch1, 2).PadLeft(8, '0');
        int p1 = Convert.ToInt32(asciiS1.Substring(0, 4), 2);
        int p2 = Convert.ToInt32(asciiS1.Substring(4, 4), 2);

        // shkronja2
        string asciiS2 = Convert.ToString((int)ch2, 2).PadLeft(8, '0');
        int p3 = Convert.ToInt32(asciiS2.Substring(0, 4), 2);
        int p4 = Convert.ToInt32(asciiS2.Substring(4, 4), 2);

        int[][] P = new int[2][];
        P[0] = new int[] { p1, p3 };
        P[1] = new int[] { p2, p4 };

      
        int[][] cipherT = Encrypt(P, K, celsi1, celsi2, celsi3);



        AppendEncryptedText(cipherT, cipherText);
        AppendDecryptedText(cipherT, decrypted);
    }

    private static void AppendEncryptedText(int[][] cipherT, StringBuilder cipherText)
    {
        string c1c2S = Convert.ToString(cipherT[0][0], 2) + Convert.ToString(cipherT[1][0], 2);
        string c1c2 = ConvertToChar(c1c2S);

        string c3c4S = Convert.ToString(cipherT[0][1], 2) + Convert.ToString(cipherT[1][1], 2);
        string c3c4 = ConvertToChar(c3c4S);

        cipherText.Append(c1c2).Append(c3c4);
    }

    private static void AppendDecryptedText(int[][] cipherT, StringBuilder decrypted)
    {
        int[][] decrypt = Decrypt(cipherT, K, celsi1, celsi2, celsi3);

        string d1d2S = Convert.ToString(decrypt[0][0], 2).PadLeft(4, '0') + Convert.ToString(decrypt[1][0], 2).PadLeft(4, '0');
        string d1d2 = ConvertToChar(d1d2S);

        string d3d4S = Convert.ToString(decrypt[0][1], 2).PadLeft(4, '0') + Convert.ToString(decrypt[1][1], 2).PadLeft(4, '0');
        string d3d4 = ConvertToChar(d3d4S);

        decrypted.Append(d1d2).Append(d3d4);
    }

    private static string ConvertToChar(string binaryString)
    {
        int charCode = Convert.ToInt32(binaryString, 2);
        return char.ConvertFromUtf32(charCode);
    }


    public static int[][] Encrypt(int[][] P, int[][] K, int[][] celsi1, int[][] celsi2, int[][] celsi3)
    {
        int[][] pak = encryption.PaK(P, K);
        int[][] Hapi1R1 = encryption.Substitution_SBOX(pak, helper.SBOX);
        int[][] Hapi2R1 = encryption.ShiftRows(Hapi1R1);
        int[][] Hapi3R1 = encryption.MixColumns(Hapi2R1);
        int[][] c1 = encryption.AddRoundKey(Hapi3R1, celsi1);

        int[][] Hapi1R2 = encryption.Substitution_SBOX(c1, helper.SBOX);
        int[][] Hapi2R2 = encryption.ShiftRows(Hapi1R2);
        int[][] Hapi3R2 = encryption.MixColumns(Hapi2R2);
        int[][] c2 = encryption.AddRoundKey(Hapi3R2, celsi2);

        int[][] Hapi1R3 = encryption.Substitution_SBOX(c2, helper.SBOX);
        int[][] Hapi2R3 = encryption.ShiftRows(Hapi1R3);
        return encryption.AddRoundKey(Hapi2R3, celsi3);
    }

    public static int[][] Decrypt(int[][] cipherText, int[][] K, int[][] celsi1, int[][] celsi2, int[][] celsi3)
    {
        int[][] addRK1 = decryption.InvAddRoundKeyD(cipherText, celsi3);
        int[][] invShift1 = decryption.InvShiftRowsD(addRK1);
        int[][] invSbox1 = decryption.InvSub(invShift1, helper.InvSBOX);

        int[][] addRK2 = decryption.InvAddRoundKeyD(invSbox1, celsi2);
        int[][] invMixC2 = decryption.InvMixColumns(addRK2);
        int[][] invShift2 = decryption.InvShiftRowsD(invMixC2);
        int[][] invSbox2 = decryption.InvSub(invShift2, helper.InvSBOX);

        int[][] addRK3 = decryption.InvAddRoundKeyD(invSbox2, celsi1);
        int[][] invMixC3 = decryption.InvMixColumns(addRK3);
        int[][] invShift3 = decryption.InvShiftRowsD(invMixC3);
        int[][] invSbox3 = decryption.InvSub(invShift3, helper.InvSBOX);

        return decryption.InvAddRoundKeyD(invSbox3, K);
    }


    public static void Main(string[] args)
    {
        SAES();
    }
}



