﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DetyraSiguriSAES
{
    class Decryption
    {
         Helper helper = new Helper();


        public Decryption() {}
        

        public int[][] InvAddRoundKeyD(int[][] d, int[][] k)
        {
            return new int[][]
            {
        new int[] { d[0][0] ^ k[0][0], d[0][1] ^ k[0][1] },
        new int[] { d[1][0] ^ k[1][0], d[1][1] ^ k[1][1] }
            };
        }

        public int[][] InvShiftRowsD(int[][] a)
        {
            int shift = a[1][0];
            a[1][0] = a[1][1];
            a[1][1] = shift;

            return a;
        }

        public int[][] InvSub(int[][] a, int[][] SB)
        {
            string s00u = Convert.ToString(a[0][0], 2);
            string s00 = s00u.PadLeft(4, '0');

            string s01u = Convert.ToString(a[0][1], 2);
            string s01 = s01u.PadLeft(4, '0');

            string s10u = Convert.ToString(a[1][0], 2);
            string s10 = s10u.PadLeft(4, '0');

            string s11u = Convert.ToString(a[1][1], 2);
            string s11 = s11u.PadLeft(4, '0');

            string B0rreshtiS = "" + s00[0] + s00[1];
            int B0rreshti = Convert.ToInt32(B0rreshtiS, 2);
            string B0kolonaS = "" + s00[2] + s00[3];
            int B0kolona = Convert.ToInt32(B0kolonaS, 2);

            string B1rreshtiS = "" + s10[0] + s10[1];
            int B1rreshti = Convert.ToInt32(B1rreshtiS, 2);
            string B1kolonaS = "" + s10[2] + s10[3];
            int B1kolona = Convert.ToInt32(B1kolonaS, 2);

            string B2rreshtiS = "" + s01[0] + s01[1];
            int B2rreshti = Convert.ToInt32(B2rreshtiS, 2);
            string B2kolonaS = "" + s01[2] + s01[3];
            int B2kolona = Convert.ToInt32(B2kolonaS, 2);

            string B3rreshtiS = "" + s11[0] + s11[1];
            int B3rreshti = Convert.ToInt32(B3rreshtiS, 2);
            string B3kolonaS = "" + s11[2] + s11[3];
            int B3kolona = Convert.ToInt32(B3kolonaS, 2);

            return new int[][]
            {
        new int[] { SB[B0rreshti][B0kolona], SB[B2rreshti][B2kolona] },
        new int[] { SB[B1rreshti][B1kolona], SB[B3rreshti][B3kolona] }
            };
        }

        public int[][] InvMixColumns(int[][] a)
        {
            int[][] MDS = new int[][] { new int[] { 15, 14 }, new int[] { 14, 14 } };

            int GF = 19;
            string gfs = Convert.ToString(GF, 2); // Convert GF to binary string if needed

            int mds0 = MDS[0][0];
            int mds1 = MDS[1][0];
            int mds2 = MDS[0][1];
            int mds3 = MDS[1][1];
            int a0 = a[0][0];
            int a1 = a[1][0];
            int a2 = a[0][1];
            int a3 = a[1][1];

            int p1 = helper.tabelaShumzimit[mds0][a0] ^ helper.tabelaShumzimit[mds2][a1];
            int p2 = helper.tabelaShumzimit[mds0][a2] ^ helper.tabelaShumzimit[mds2][a3];
            int p3 = helper.tabelaShumzimit[mds1][a0] ^ helper.tabelaShumzimit[mds3][a1];
            int p4 = helper.tabelaShumzimit[mds1][a2] ^ helper.tabelaShumzimit[mds3][a3];

            return new int[][] { new int[] { p1, p2 }, new int[] { p3, p4 } };
        }


    }
}
