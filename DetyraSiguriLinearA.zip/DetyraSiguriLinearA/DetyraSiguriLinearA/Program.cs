﻿using DetyraSiguriLinearA;
using System.Text;

namespace DetyraSiguriLinearA
{
    class Decryption
    {
        Helper helper = new Helper();


        public Decryption() { }


        public int[][] InvAddRoundKeyD(int[][] d, int[][] k)
        {
            return new int[][]
            {
        new int[] { d[0][0] ^ k[0][0], d[0][1] ^ k[0][1] },
        new int[] { d[1][0] ^ k[1][0], d[1][1] ^ k[1][1] }
            };
        }

        public int[][] InvShiftRowsD(int[][] a)
        {
            int shift = a[1][0];
            a[1][0] = a[1][1];
            a[1][1] = shift;

            return a;
        }

        public int[][] InvSub(int[][] a, int[][] SB)
        {
            string s00u = Convert.ToString(a[0][0], 2);
            string s00 = s00u.PadLeft(4, '0');

            string s01u = Convert.ToString(a[0][1], 2);
            string s01 = s01u.PadLeft(4, '0');

            string s10u = Convert.ToString(a[1][0], 2);
            string s10 = s10u.PadLeft(4, '0');

            string s11u = Convert.ToString(a[1][1], 2);
            string s11 = s11u.PadLeft(4, '0');

            string B0rreshtiS = "" + s00[0] + s00[1];
            int B0rreshti = Convert.ToInt32(B0rreshtiS, 2);
            string B0kolonaS = "" + s00[2] + s00[3];
            int B0kolona = Convert.ToInt32(B0kolonaS, 2);

            string B1rreshtiS = "" + s10[0] + s10[1];
            int B1rreshti = Convert.ToInt32(B1rreshtiS, 2);
            string B1kolonaS = "" + s10[2] + s10[3];
            int B1kolona = Convert.ToInt32(B1kolonaS, 2);

            string B2rreshtiS = "" + s01[0] + s01[1];
            int B2rreshti = Convert.ToInt32(B2rreshtiS, 2);
            string B2kolonaS = "" + s01[2] + s01[3];
            int B2kolona = Convert.ToInt32(B2kolonaS, 2);

            string B3rreshtiS = "" + s11[0] + s11[1];
            int B3rreshti = Convert.ToInt32(B3rreshtiS, 2);
            string B3kolonaS = "" + s11[2] + s11[3];
            int B3kolona = Convert.ToInt32(B3kolonaS, 2);

            return new int[][]
            {
        new int[] { SB[B0rreshti][B0kolona], SB[B2rreshti][B2kolona] },
        new int[] { SB[B1rreshti][B1kolona], SB[B3rreshti][B3kolona] }
            };
        }

        public int[][] InvMixColumns(int[][] a)
        {
            int[][] MDS = new int[][] { new int[] { 15, 14 }, new int[] { 14, 14 } };

            int GF = 19;
            string gfs = Convert.ToString(GF, 2);

            int mds0 = MDS[0][0];
            int mds1 = MDS[1][0];
            int mds2 = MDS[0][1];
            int mds3 = MDS[1][1];
            int a0 = a[0][0];
            int a1 = a[1][0];
            int a2 = a[0][1];
            int a3 = a[1][1];

            int p1 = helper.tabelaShumzimit[mds0][a0] ^ helper.tabelaShumzimit[mds2][a1];
            int p2 = helper.tabelaShumzimit[mds0][a2] ^ helper.tabelaShumzimit[mds2][a3];
            int p3 = helper.tabelaShumzimit[mds1][a0] ^ helper.tabelaShumzimit[mds3][a1];
            int p4 = helper.tabelaShumzimit[mds1][a2] ^ helper.tabelaShumzimit[mds3][a3];

            return new int[][] { new int[] { p1, p2 }, new int[] { p3, p4 } };
        }


    }
}
namespace DetyraSiguriLinearA
{
    internal class Encryption
    {

        public Helper helper = new Helper();

        public Encryption() { }

        public int[][] PaK(int[][] P, int[][] K)
        {
            return new int[][]
            {
        new int[] { P[0][0] ^ K[0][0], P[0][1] ^ K[0][1] },
        new int[] { P[1][0] ^ K[1][0], P[1][1] ^ K[1][1] }
            };
        }

        public int[][] ShiftRows(int[][] a)
        {
            int save1 = a[1][0];
            a[1][0] = a[1][1];
            a[1][1] = save1;

            return a;
        }

        public int[][] Substitution_SBOX(int[][] a, int[][] SB)
        {
            int[][] result = new int[2][];
            for (int i = 0; i < 2; i++)
            {
                result[i] = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    string binary = Convert.ToString(a[i][j], 2).PadLeft(4, '0');
                    int row = Convert.ToInt32(binary.Substring(0, 2), 2);
                    int col = Convert.ToInt32(binary.Substring(2, 2), 2);
                    result[i][j] = SB[row][col];
                }
            }
            return result;
        }

        public int[][] MixColumns(int[][] a)
        {
            int[][] MDS = new int[][] { new int[] { 1, 1 }, new int[] { 1, 2 } };

            int mds0 = MDS[0][0];
            int mds1 = MDS[1][0];
            int mds2 = MDS[0][1];
            int mds3 = MDS[1][1];

            int a0 = a[0][0];
            int a1 = a[1][0];//a1 og
            int a2 = a[0][1];//a2 og
            int a3 = a[1][1];

            int p1 = helper.tabelaShumzimit[mds0][a0] ^ helper.tabelaShumzimit[mds2][a1];
            int p2 = helper.tabelaShumzimit[mds0][a2] ^ helper.tabelaShumzimit[mds2][a3];
            int p3 = helper.tabelaShumzimit[mds1][a0] ^ helper.tabelaShumzimit[mds3][a1];
            int p4 = helper.tabelaShumzimit[mds1][a2] ^ helper.tabelaShumzimit[mds3][a3];

            return new int[][]
            {
        new int[] { p1, p2 },
        new int[] { p3, p4 }
            };
        }

        public int[][] AddRoundKey(int[][] d, int[][] k)
        {
            return new int[][]
            {
        new int[] { d[0][0] ^ k[0][0], d[0][1] ^ k[0][1] },
        new int[] { d[1][0] ^ k[1][0], d[1][1] ^ k[1][1] }
            };
        }



        public void PrintMatrix(int[][] matrix)
        {

            for (int i = 0; i < matrix.Length; i++)
            {
                for (int j = 0; j < matrix[i].Length; j++)
                {
                    Console.Write(matrix[i][j] + " ");
                }
                Console.WriteLine();
            }
        }

    }
}

namespace DetyraSiguriLinearA
{
    internal class Helper
    {
        public int[][] SBOX = new int[][]
{    new int[] { 6, 11, 0, 4 },    new int[] { 7, 14, 2, 15 },    new int[] { 9, 8, 10, 12 },    new int[] { 3, 1, 5, 13 }        };


        public int[][] tabelaShumzimit = new int[][]
{
    new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
    new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 },
    new int[] { 0, 2, 4, 6, 8, 10, 12, 14, 3, 1, 7, 5, 11, 9, 15, 13 },
    new int[] { 0, 3, 6, 5, 12, 15, 10, 9, 11, 8, 13, 14, 7, 4, 1, 2 },
    new int[] { 0, 4, 8, 12, 3, 7, 11, 15, 6, 2, 14, 10, 5, 1, 13, 9 },
    new int[] { 0, 5, 10, 15, 7, 2, 13, 8, 14, 11, 4, 1, 9, 12, 3, 6 },
    new int[] { 0, 6, 12, 10, 11, 13, 7, 1, 5, 3, 9, 15, 14, 8, 2, 4 },
    new int[] { 0, 7, 14, 9, 15, 8, 1, 6, 13, 10, 3, 4, 2, 5, 12, 11 },
    new int[] { 0, 8, 3, 11, 6, 14, 5, 13, 12, 4, 15, 7, 10, 2, 9, 1 },
    new int[] { 0, 9, 1, 8, 2, 11, 3, 10, 4, 13, 5, 12, 6, 15, 7, 14 },
    new int[] { 0, 10, 7, 13, 14, 4, 9, 3, 15, 5, 8, 2, 1, 11, 6, 12 },
    new int[] { 0, 11, 5, 14, 10, 1, 15, 4, 7, 12, 2, 9, 13, 6, 8, 3 },
    new int[] { 0, 12, 11, 7, 5, 9, 14, 2, 10, 6, 1, 13, 15, 3, 4, 8 },
    new int[] { 0, 13, 9, 4, 1, 12, 8, 5, 2, 15, 11, 6, 3, 14, 10, 7 },
    new int[] { 0, 14, 15, 1, 13, 3, 2, 12, 9, 7, 6, 8, 4, 10, 11, 5 },
    new int[] { 0, 15, 13, 2, 9, 6, 4, 11, 1, 14, 12, 3, 8, 7, 5, 10 }
};
        public int[][] InvSBOX = new int[][]
{
    new int[] { 2, 13, 6, 12 },
    new int[] { 3, 14, 0, 4 },
    new int[] { 9, 8, 10, 1 },
    new int[] { 11, 15, 5, 7 }
};
        public int G(int a, int rundi, int[][] SB)
        {
            string ku = Convert.ToString(a, 2);
            string k = ku.PadLeft(4, '0');

            string k0S = k[3].ToString();
            string k1S = k[1].ToString();
            string k2S = k[2].ToString();
            string k3S = k[0].ToString();

            string rreshtiS = k1S + k2S;
            int rreshti = Convert.ToInt32(rreshtiS, 2);

            string kolonaS = k0S + k3S;
            int kolona = Convert.ToInt32(kolonaS, 2);

            int subytes = SB[rreshti][kolona];

            if (rundi == 1)
            {
                return subytes ^ 1;
            }
            else if (rundi == 2)
            {
                return 2 ^ subytes;
            }
            else if (rundi == 3)
            {
                return 4 ^ subytes;
            }

            return -1;
        }


        public int[][] KeyGenerator(int[][] C, int rundi, int[][] SB)
        {


            int k0 = C[0][0];
            int k1 = C[1][0];
            int k2 = C[0][1];
            int k3 = C[1][1];
            int Gk3 = G(k3, rundi, SB);

            int kp0 = k0 ^ Gk3;
            int kp1 = k1 ^ kp0;
            int kp2 = k2 ^ kp1;
            int kp3 = k3 ^ kp2;

            return new int[][]
            {
        new int[] { kp0, kp2 },
        new int[] { kp1, kp3 }
            };
        }
        public int[][] GCMXOR(int[][] a, int[][] b)
        {
            return new int[][]
            {
        new int[] { a[0][0] ^ b[0][0], a[0][1] ^ b[0][1] },
        new int[] { a[1][0] ^ b[1][0], a[1][1] ^ b[1][1] }
            };
        }

    }
}


public class AESProcessor
{
    private static int[][] P = new int[][] { new int[] { 1, 1 }, new int[] { 1, 1 } };
    private static int[][] K = new int[][] { new int[] { 10, 5 }, new int[] { 3, 12 } };
    static Helper helper = new Helper();
    static Encryption encryption = new Encryption();
    static Decryption decryption = new Decryption();
    static int[][] celsi1 = helper.KeyGenerator(K, 1, helper.SBOX);
    static int[][] celsi2 = helper.KeyGenerator(celsi1, 2, helper.SBOX);
    static int[][] celsi3 = helper.KeyGenerator(celsi2, 3, helper.SBOX);

    public static void SAES()
    {
        StringBuilder decrypted = new StringBuilder();
        StringBuilder cipherText = new StringBuilder();


        string inputFilePath = "C:\\Program Files\\ProgramRepos\\DetyraSiguriLinearA\\DetyraSiguriLinearA\\plaintext.txt";
       


        string file = File.ReadAllText(inputFilePath);


        if (file.Length % 2 != 0)
        {
            file += " ";
        }


        for (int i = 0; i < file.Length; i += 2)
        {
            ProcessPair(file[i], file[i + 1], cipherText, decrypted, "saes");
        }

    }


    private static void ProcessPair(char ch1, char ch2, StringBuilder cipherText, StringBuilder decrypted, string mode)
    {



        string asciiS1 = Convert.ToString((int)ch1, 2).PadLeft(8, '0');
        int p1 = Convert.ToInt32(asciiS1.Substring(0, 4), 2);
        int p2 = Convert.ToInt32(asciiS1.Substring(4, 4), 2);


        string asciiS2 = Convert.ToString((int)ch2, 2).PadLeft(8, '0');
        int p3 = Convert.ToInt32(asciiS2.Substring(0, 4), 2);
        int p4 = Convert.ToInt32(asciiS2.Substring(4, 4), 2);

        int[][] P = new int[2][];
        P[0] = new int[] { p1, p3 };
        P[1] = new int[] { p2, p4 };


        int[][] cipherT = Encrypt(P, K, celsi1, celsi2, celsi3);



        AppendEncryptedText(cipherT, cipherText);
        AppendDecryptedText(cipherT, decrypted);
    }

    private static void AppendEncryptedText(int[][] cipherT, StringBuilder cipherText)
    {
        string c1c2S = Convert.ToString(cipherT[0][0], 2) + Convert.ToString(cipherT[1][0], 2);
        string c1c2 = ConvertToChar(c1c2S);

        string c3c4S = Convert.ToString(cipherT[0][1], 2) + Convert.ToString(cipherT[1][1], 2);
        string c3c4 = ConvertToChar(c3c4S);

        cipherText.Append(c1c2).Append(c3c4);
    }

    private static void AppendDecryptedText(int[][] cipherT, StringBuilder decrypted)
    {
        int[][] decrypt = Decrypt(cipherT, K, celsi1, celsi2, celsi3);

        string d1d2S = Convert.ToString(decrypt[0][0], 2).PadLeft(4, '0') + Convert.ToString(decrypt[1][0], 2).PadLeft(4, '0');
        string d1d2 = ConvertToChar(d1d2S);

        string d3d4S = Convert.ToString(decrypt[0][1], 2).PadLeft(4, '0') + Convert.ToString(decrypt[1][1], 2).PadLeft(4, '0');
        string d3d4 = ConvertToChar(d3d4S);

        decrypted.Append(d1d2).Append(d3d4);
    }

    private static string ConvertToChar(string binaryString)
    {
        int charCode = Convert.ToInt32(binaryString, 2);
        return char.ConvertFromUtf32(charCode);
    }


    public static int[][] Encrypt(int[][] P, int[][] K, int[][] celsi1, int[][] celsi2, int[][] celsi3)
    {
        int[][] pak = encryption.PaK(P, K);
        int[][] Hapi1R1 = encryption.Substitution_SBOX(pak, helper.SBOX);
        int[][] Hapi2R1 = encryption.ShiftRows(Hapi1R1);
        int[][] Hapi3R1 = encryption.MixColumns(Hapi2R1);
        int[][] c1 = encryption.AddRoundKey(Hapi3R1, celsi1);

        int[][] Hapi1R2 = encryption.Substitution_SBOX(c1, helper.SBOX);
        int[][] Hapi2R2 = encryption.ShiftRows(Hapi1R2);
        int[][] Hapi3R2 = encryption.MixColumns(Hapi2R2);
        int[][] c2 = encryption.AddRoundKey(Hapi3R2, celsi2);

        int[][] Hapi1R3 = encryption.Substitution_SBOX(c2, helper.SBOX);
        int[][] Hapi2R3 = encryption.ShiftRows(Hapi1R3);
        return encryption.AddRoundKey(Hapi2R3, celsi3);
    }

    public static int[][] Decrypt(int[][] cipherText, int[][] K, int[][] celsi1, int[][] celsi2, int[][] celsi3)
    {
        int[][] addRK1 = decryption.InvAddRoundKeyD(cipherText, celsi3);
        int[][] invShift1 = decryption.InvShiftRowsD(addRK1);
        int[][] invSbox1 = decryption.InvSub(invShift1, helper.InvSBOX);

        int[][] addRK2 = decryption.InvAddRoundKeyD(invSbox1, celsi2);
        int[][] invMixC2 = decryption.InvMixColumns(addRK2);
        int[][] invShift2 = decryption.InvShiftRowsD(invMixC2);
        int[][] invSbox2 = decryption.InvSub(invShift2, helper.InvSBOX);

        int[][] addRK3 = decryption.InvAddRoundKeyD(invSbox2, celsi1);
        int[][] invMixC3 = decryption.InvMixColumns(addRK3);
        int[][] invShift3 = decryption.InvShiftRowsD(invMixC3);
        int[][] invSbox3 = decryption.InvSub(invShift3, helper.InvSBOX);

        return decryption.InvAddRoundKeyD(invSbox3, K);
    }

}

public class LinearCryptanalysis
{
    static Helper helper = new Helper();
    static Encryption encryption = new Encryption();
    static int[][] K = new int[][] { new int[] { 10, 5 }, new int[] { 3, 12 } };

    public static void PerformLinear()
    {
        // gjenereimi i cifteve
        List<(int[][] plaintext, int[][] ciphertext)> pairs = GeneratePairs();

        // brute
        for (int k0 = 0; k0 < 16; k0++)
        {
            for (int k1 = 0; k1 < 16; k1++)
            {
                for (int k2 = 0; k2 < 16; k2++)
                {
                    for (int k3 = 0; k3 < 16; k3++)
                    {
                        int[][] key = new int[][] { new int[] { k0, k2 }, new int[] { k1, k3 } };

                        // test
                        if (TestPairs(key, pairs))
                        {
                            Console.WriteLine($"Found key: [{k0}, {k1}, {k2}, {k3}]");
                            return;
                        }
                    }
                }
            }
        }

        Console.WriteLine("No key found.");
    }

    private static List<(int[][] plaintext, int[][] ciphertext)> GeneratePairs()
    {
        var pairs = new List<(int[][], int[][])>();


        int[][] plaintext1 = new int[][] { new int[] { 0, 0 }, new int[] { 0, 0 } };
        int[][] plaintext2 = new int[][] { new int[] { 1, 0 }, new int[] { 0, 0 } };

        int[][] ciphertext1 = Encrypt(plaintext1, K);
        int[][] ciphertext2 = Encrypt(plaintext2, K);

        pairs.Add((plaintext1, ciphertext1));
        pairs.Add((plaintext2, ciphertext2));

        return pairs;
    }

    private static bool TestPairs(int[][] key, List<(int[][] plaintext, int[][] ciphertext)> pairs)
    {
        foreach (var (plaintext, ciphertext) in pairs)
        {
            int[][] enc = Encrypt(plaintext, key);
            if (!AreMatricesEqual(enc, ciphertext))
            {
                return false;
            }
        }
        return true;
    }

    private static bool AreMatricesEqual(int[][] a, int[][] b)
    {
        for (int i = 0; i < a.Length; i++)
        {
            for (int j = 0; j < a[i].Length; j++)
            {
                if (a[i][j] != b[i][j])
                {
                    return false;
                }
            }
        }
        return true;
    }

    public static int[][] Encrypt(int[][] P, int[][] key)
    {
        int[][] pak = encryption.PaK(P, key);
        int[][] Hapi1R1 = encryption.Substitution_SBOX(pak, helper.SBOX);
        int[][] Hapi2R1 = encryption.ShiftRows(Hapi1R1);
        return encryption.AddRoundKey(Hapi2R1, key);
    }

    public static void Main(string[] args)
    {
        PerformLinear();
    }
}