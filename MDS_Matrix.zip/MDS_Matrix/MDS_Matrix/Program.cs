﻿using System;

class GaloisField
{
    private static readonly int POLY = 0x11B; // polinomi iruducibil x^8 + x^4 + x^3 + x + 1

    
    public static int GfAdd(int a, int b)
    {
        return a ^ b;
    }

   
    public static int GfMult(int a, int b)
    {
        int result = 0;
        while (b > 0)
        {
            if ((b & 1) != 0)
                result ^= a;

            a <<= 1;

            if (a >= 0x100)  // overflow
                a ^= POLY;

            b >>= 1;
        }
        return result;
    }
}

class MatrixOperations
{
    
    public static int[,] GenerateRandomMatrix(int size = 4)
    {
        Random rnd = new Random();
        int[,] matrix = new int[size, size];
        for (int i = 0; i < size; i++)
            for (int j = 0; j < size; j++)
                matrix[i, j] = rnd.Next(0, 256);  

        return matrix;
    }

    
    public static int[,] GfMatrixMult(int[,] A, int[,] B, int size = 4)
    {
        int[,] C = new int[size, size];
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                C[i, j] = 0;
                for (int k = 0; k < size; k++)
                {
                    C[i, j] ^= GaloisField.GfMult(A[i, k], B[k, j]);
                }
            }
        }
        return C;
    }

    
    public static int HammingDistance(int a, int b)
    {
        return Convert.ToString(a ^ b, 2).Replace("0", "").Length;
    }

   
    public static int[,] GenA_Prime(int[,] A, int[,] B, int[,] MDS, int size = 4)
    {
        int[,] A_prime = new int[size, size];
        Random rnd = new Random();

        
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                A_prime[i, j] = A[i, j];
            }
        }

        bool conditionMet = false;
        while (!conditionMet)
        {
            // Flip bits 
            for (int j = 0; j < size; j++)  
            {
                for (int i = 0; i < size; i++) 
                {
                    int bitToFlip = rnd.Next(0, 8);
                    A_prime[i, j] ^= (1 << bitToFlip);  // Flip random bit
                }
            }

        
            int[,] B_prime = GfMatrixMult(MDS, A_prime, size);

          
            conditionMet = true;
            for (int col = 0; col < size; col++)
            {
                int packedB = PackColumn(B, col);
                int packedB_prime = PackColumn(B_prime, col);
                int hammingDistance = HammingDistance(packedB, packedB_prime);

                if (hammingDistance < 16)
                {
                    conditionMet = false;
                    break;
                }
            }
        }

        return A_prime;
    }

  
    public static int PackColumn(int[,] matrix, int column)
    {
        int packed = 0;
        for (int row = 0; row < 4; row++)
        {
            packed |= (matrix[row, column] << (row * 8));
        }
        return packed;
    }
}

class Program
{
    static void Main(string[] args)
    {
        int size = 4;


        int[,] MDS = new int[,]
        {
            { 0x02, 0x03, 0x01, 0x01 },
            { 0x01, 0x02, 0x03, 0x01 },
            { 0x01, 0x01, 0x02, 0x03 },
            { 0x03, 0x01, 0x01, 0x02 }
        };

        // gen random matrix
        int[,] A = MatrixOperations.GenerateRandomMatrix(size);

        // multiply MDS * A 
        int[,] B = MatrixOperations.GfMatrixMult(MDS, A, size);

        // generate matrix A' 
        int[,] A_prime = MatrixOperations.GenA_Prime(A, B, MDS, size);

        // multiply MDS * A' 
        int[,] B_prime = MatrixOperations.GfMatrixMult(MDS, A_prime, size);

        // check
        for (int col = 0; col < size; col++)
        {
            int packedB = MatrixOperations.PackColumn(B, col);
            int packedB_prime = MatrixOperations.PackColumn(B_prime, col);

            int hammingDistance = MatrixOperations.HammingDistance(packedB, packedB_prime);

            Console.WriteLine($"Hamming distance for column {col}: {hammingDistance}");
            if (hammingDistance < 16)
            {
                Console.WriteLine("Hamming distance less than 16!");
                return;
            }
        }

        Console.WriteLine("Hamming distance >=16!");
    }
}
